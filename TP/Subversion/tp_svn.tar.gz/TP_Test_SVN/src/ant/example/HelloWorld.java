package ant.example;

/**
   Main class example for ant
   @author Julien Derveeuw
*/
public class HelloWorld
{
    public static void main(String args[])
    {
	  System.out.println("Hello world !");
    }
}
